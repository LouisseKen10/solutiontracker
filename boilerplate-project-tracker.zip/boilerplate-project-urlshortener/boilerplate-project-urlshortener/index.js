require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const dns = require('dns');
const cors = require('cors');
dns.setServers(['8.8.8.8', '1.1.1.1']);
const app = express();

const PORT = process.env.PORT || 3000;

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('Louisse Ken Exercise Tracker: database connected'))
  .catch(error => console.error(error));

const memberSchema = new mongoose.Schema({
  username: { type: String, required: true }
});
const Member = mongoose.model('Member', memberSchema);

const workoutSchema = new mongoose.Schema({
  memberId: { type: String, required: true },
  description: { type: String, required: true },
  duration: { type: Number, required: true },
  date: { type: Date, required: true }
});
const Workout = mongoose.model('Workout', workoutSchema);

app.use(cors());
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/index.html');
});

app.post('/api/users', async (req, res) => {
  try {
    const member = await Member.create({ username: req.body.username });
    res.json({ username: member.username, _id: member._id });
  } catch (error) {
    res.json({ error: 'could not create user' });
  }
});

app.get('/api/users', async (req, res) => {
  const members = await Member.find({}, 'username _id');
  res.json(members);
});

app.post('/api/users/:_id/exercises', async (req, res) => {
  try {
    const member = await Member.findById(req.params._id);
    if (!member) return res.json({ error: 'user not found' });

    const { description, duration, date } = req.body;
    const workoutDate = date ? new Date(date) : new Date();
    if (isNaN(workoutDate.getTime())) return res.json({ error: 'invalid date' });

    const workout = await Workout.create({
      memberId: member._id.toString(),
      description,
      duration: Number(duration),
      date: workoutDate
    });

    res.json({
      _id: member._id,
      username: member.username,
      date: workout.date.toDateString(),
      duration: workout.duration,
      description: workout.description
    });
  } catch (error) {
    res.json({ error: 'could not add exercise' });
  }
});

app.get('/api/users/:_id/logs', async (req, res) => {
  try {
    const member = await Member.findById(req.params._id);
    if (!member) return res.json({ error: 'user not found' });

    const { from, to, limit } = req.query;
    const filter = { memberId: member._id.toString() };

    if (from || to) {
      filter.date = {};
      if (from) filter.date.$gte = new Date(from);
      if (to) filter.date.$lte = new Date(to);
    }

    let query = Workout.find(filter).sort({ date: 1 });
    if (limit) query = query.limit(Number(limit));
    const workouts = await query;

    res.json({
      _id: member._id,
      username: member.username,
      count: workouts.length,
      log: workouts.map(item => ({
        description: item.description,
        duration: item.duration,
        date: item.date.toDateString()
      }))
    });
  } catch (error) {
    res.json({ error: 'could not get logs' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});